//	Generated using Unvired Modeller - Build R-4.000.0120

using System;
using System.Text;

namespace UNVIRED_REST_SAMPLE.Utility
{

    public partial class AppConstants
    {
        // App Name
        public const string APP_NAME = "UNVIRED_REST_SAMPLE";

        // BE Names
        public const string BE_WEATHER = "WEATHER";


        // PA Function Names
        public const string PA_GET_WEATHER = "UNVIRED_REST_SAMPLE_PA_GET_WEATHER"; // Get Weather

    }
}